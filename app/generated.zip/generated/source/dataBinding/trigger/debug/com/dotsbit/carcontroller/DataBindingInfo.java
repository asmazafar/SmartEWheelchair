package com.dotsbit.carcontroller;

import androidx.databinding.BindingBuildInfo;

@BindingBuildInfo
public class DataBindingInfo {}
